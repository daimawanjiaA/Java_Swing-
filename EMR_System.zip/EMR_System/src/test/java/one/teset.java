package test.java.one;

public class teset {
    public static void main(String[] args) {
        String st1 = "我";
        String st2 = "我";
        //System.out.println("我".equals(st1)); true
        //System.out.println(st2.equals(st1)); true
        //System.out.println("我".equals("我"));
        /*JframeTest jframeTest1 = new JframeTest();
        JframeTest jframeTest2 = new JframeTest();
        System.out.println(jframeTest1.equals(jframeTest2));//false
         */
    }
}
