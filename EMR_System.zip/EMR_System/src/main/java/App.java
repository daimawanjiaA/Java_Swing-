package main.java;

import main.java.EMRView.MenuView;

public class App {
    public static void main(String[] args) {
        new MenuView();
    }
}
