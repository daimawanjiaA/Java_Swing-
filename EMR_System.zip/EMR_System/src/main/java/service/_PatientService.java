package main.java.service;

public interface _PatientService {
}
