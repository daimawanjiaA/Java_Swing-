package main.java.util;

public class OperationHintPannel {

//    public OperationHintPannel(JFrame jFrame, String string) {
//        JDialog jdlg = new JDialog(jFrame, "结果提示", true);
//        JLabel name = new JLabel("     " + string);
//        name.setFont(new Font("黑体", Font.PLAIN, 30));
//        name.setForeground(Color.RED);
//        jdlg.add(name);
//        jdlg.setSize(300, 200);
//        jdlg.setLocationRelativeTo(null);
//        jdlg.setResizable(false);
//        jdlg.setVisible(true);
//    }
}