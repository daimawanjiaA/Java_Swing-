package com.xu.entity;

public class jiwangshi {
	private String 病人身份证号;
	private String 疾病;


	public String get病人身份证号() {
		return 病人身份证号;
	}
	public void set病人身份证号(String 病人身份证号) {
		this.病人身份证号 = 病人身份证号;
	}
	public String get疾病() {
		return 疾病;
	}
	public void set疾病(String 疾病) {
		this.疾病 = 疾病;
	}


}
