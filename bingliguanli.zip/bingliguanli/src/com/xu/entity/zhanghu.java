package com.xu.entity;

public class zhanghu {
	private String 账号;
	private String 密码;
	private String 管理员工号;
	private Integer 账户性质;
	public String get账号() {
		return 账号;
	}
	public void set账号(String 账号) {
		this.账号 = 账号;
	}
	public String get密码() {
		return 密码;
	}
	public void set密码(String 密码) {
		this.密码 = 密码;
	}
	public String get管理员工号() {
		return 管理员工号;
	}
	public void set管理员工号(String 管理员工号) {
		this.管理员工号 = 管理员工号;
	}
	public Integer get账户性质() {
		return 账户性质;
	}
	public void set账户性质(Integer 账户性质) {
		this.账户性质 = 账户性质;
	}


}
