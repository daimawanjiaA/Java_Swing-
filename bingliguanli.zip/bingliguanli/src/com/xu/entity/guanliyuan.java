package com.xu.entity;

public class guanliyuan {
	private String 工号;
	private String 姓名;
	private String 性别;
	private String 联系方式;
	public String get工号() {
		return 工号;
	}
	public void set工号(String 工号) {
		this.工号 = 工号;
	}
	public String get姓名() {
		return 姓名;
	}
	public void set姓名(String 姓名) {
		this.姓名 = 姓名;
	}
	public String get性别() {
		return 性别;
	}
	public void set性别(String 性别) {
		this.性别 = 性别;
	}
	public String get联系方式() {
		return 联系方式;
	}
	public void set联系方式(String 联系方式) {
		this.联系方式 = 联系方式;
	}


}
