package com.xu.entity;

import java.util.List;

public class bingren {
	private String 身份证号;
	private String 姓名;
	private String 性别;
	private int 年龄;
	private String 籍贯;
	private String 住址;
	private String 联系方式;
	private String 职业;
	private String 婚姻状况;
	private String 过敏药物;
	private String 既往史;
	private String 账号;


	public String get身份证号() {
		return 身份证号;
	}
	public void set身份证号(String 身份证号) {
		this.身份证号 = 身份证号;
	}
	public String get姓名() {
		return 姓名;
	}
	public void set姓名(String 姓名) {
		this.姓名 = 姓名;
	}
	public String get性别() {
		return 性别;
	}
	public void set性别(String 性别) {
		this.性别 = 性别;
	}
	public int get年龄() {
		return 年龄;
	}
	public void set年龄(int 年龄) {
		this.年龄 = 年龄;
	}
	public String get籍贯() {
		return 籍贯;
	}
	public void set籍贯(String 籍贯) {
		this.籍贯 = 籍贯;
	}
	public String get住址() {
		return 住址;
	}
	public void set住址(String 住址) {
		this.住址 = 住址;
	}
	public String get联系方式() {
		return 联系方式;
	}
	public void set联系方式(String 联系方式) {
		this.联系方式 = 联系方式;
	}
	public String get职业() {
		return 职业;
	}
	public void set职业(String 职业) {
		this.职业 = 职业;
	}
	public String get婚姻状况() {
		return 婚姻状况;
	}
	public void set婚姻状况(String 婚姻状况) {
		this.婚姻状况 = 婚姻状况;
	}

	public String get过敏药物() {
		return 过敏药物;
	}
	public void set过敏药物(String 过敏药物) {
		this.过敏药物 = 过敏药物;
	}
	public String get既往史() {
		return 既往史;
	}
	public void set既往史(String 既往史) {
		this.既往史 = 既往史;
	}
	public String get账号() {
		return 账号;
	}
	public void set账号(String 账号) {
		this.账号 = 账号;
	}


}
