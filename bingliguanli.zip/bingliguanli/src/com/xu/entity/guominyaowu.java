package com.xu.entity;

public class guominyaowu {
	private String 病人身份证号;
	private String 药物名称;


	public String get病人身份证号() {
		return 病人身份证号;
	}
	public void set病人身份证号(String 病人身份证号) {
		this.病人身份证号 = 病人身份证号;
	}
	public String get药物名称() {
		return 药物名称;
	}
	public void set药物名称(String 药物名称) {
		this.药物名称 = 药物名称;
	}


}
