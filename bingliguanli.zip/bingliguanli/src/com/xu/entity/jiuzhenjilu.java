package com.xu.entity;

import java.sql.*;

public class jiuzhenjilu {
	private String 病人身份证号;
	private String 医生工号;
	private Date 日期;
	private String 疾病;
	private String 症状;
	private String 检查项目;
	private String 医嘱;
	private Date 入院时间;
	private Date 出院时间;
	private Date 下次复诊时间;
	public String get病人身份证号() {
		return 病人身份证号;
	}
	public void set病人身份证号(String 病人身份证号) {
		this.病人身份证号 = 病人身份证号;
	}
	public String get医生工号() {
		return 医生工号;
	}
	public void set医生工号(String 医生工号) {
		this.医生工号 = 医生工号;
	}
	public Date get日期() {
		return 日期;
	}
	public void set日期(Date 日期) {
		this.日期 = 日期;
	}
	public String get疾病() {
		return 疾病;
	}
	public void set疾病(String 疾病) {
		this.疾病 = 疾病;
	}
	public String get症状() {
		return 症状;
	}
	public void set症状(String 症状) {
		this.症状 = 症状;
	}
	public String get检查项目() {
		return 检查项目;
	}
	public void set检查项目(String 检查项目) {
		this.检查项目 = 检查项目;
	}
	public String get医嘱() {
		return 医嘱;
	}
	public void set医嘱(String 医嘱) {
		this.医嘱 = 医嘱;
	}
	public Date get入院时间() {
		return 入院时间;
	}
	public void set入院时间(Date 入院时间) {
		this.入院时间 = 入院时间;
	}
	public Date get出院时间() {
		return 出院时间;
	}
	public void set出院时间(Date 出院时间) {
		this.出院时间 = 出院时间;
	}
	public Date get下次复诊时间() {
		return 下次复诊时间;
	}
	public void set下次复诊时间(Date 下次复诊时间) {
		this.下次复诊时间 = 下次复诊时间;
	}


}
