package com.xu.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.xu.entity.jiwangshi;
import com.xu.utils.DBConn;

public class jiwangshiDao {

	public boolean insert(jiwangshi 既往史) {
		boolean flag = false;
		DBConn.init();
		int i =DBConn.addUpdDel("insert into 既往史(病人身份证号,疾病) " +
				"values('"+既往史.get病人身份证号()+"','"+既往史.get疾病()+"')");
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	public boolean selectCondition1(String 病人身份证号) {
		boolean flag = false;
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from 既往史 where 病人身份证号='"+病人身份证号+"'");
			while(rs.next()){
				if(rs.getString("病人身份证号").equals(病人身份证号)){
					flag = true;
				}
			}
			DBConn.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	//根据病人身份证号 查询他的既往史  放在List<String> 链表中
	public List<String> SelectBy身份证号(String 病人身份证号) {
		List<String> list = new ArrayList<String>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from 既往史 where 病人身份证号 = '" + 病人身份证号+"'");
			while(rs.next()) {
				list.add(rs.getString("疾病"));
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<jiwangshi> get既往史All() {
		List<jiwangshi> list = new ArrayList<jiwangshi>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from 既往史");
			while(rs.next()){
				jiwangshi 既往史 = new jiwangshi();
				既往史.set病人身份证号(rs.getString("病人身份证号"));
				既往史.set疾病(rs.getString("疾病"));
				list.add(既往史);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public boolean update(String 病人身份证号, String 疾病,String 性别, String 联系方式) {
		boolean flag = false;
		DBConn.init();
		String sql ="update 既往史 set 疾病 ='"+疾病
				+"' where 病人身份证号 = '"+病人身份证号+ "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	public boolean delete(String 病人身份证号, String 疾病) {
		boolean flag = false;
		DBConn.init();
		String sql = "delete  from 既往史 where 病人身份证号= '"+病人身份证号 + "' AND 疾病 = '" + 疾病 + "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}

}
