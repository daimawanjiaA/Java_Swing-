package com.xu.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.xu.entity.guominyaowu;
import com.xu.utils.DBConn;

public class guominyaowuDao {

	public boolean insert(guominyaowu 过敏药物) {
		boolean flag = false;
		DBConn.init();
		int i =DBConn.addUpdDel("insert into 过敏药物(病人身份证号,药物名称) " +
				"values('"+过敏药物.get病人身份证号()+"','"+过敏药物.get药物名称()+"')");
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	public boolean selectCondition1(String 病人身份证号) {
		boolean flag = false;
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from 过敏药物 where 病人身份证号='"+病人身份证号+"'");
			while(rs.next()){
				if(rs.getString("病人身份证号").equals(病人身份证号)){
					flag = true;
				}
			}
			DBConn.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	//根据病人身份证号 查询他的过敏药物  放在List<String> 链表中
	public List<String> SelectBy身份证号(String 病人身份证号) {
		List<String> list = new ArrayList<String>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from 过敏药物 where 病人身份证号 = '" + 病人身份证号+"'");
			while(rs.next()) {
				list.add(rs.getString("药物名称"));
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<guominyaowu> get过敏药物All() {
		List<guominyaowu> list = new ArrayList<guominyaowu>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from 过敏药物");
			while(rs.next()){
				guominyaowu 过敏药物 = new guominyaowu();
				过敏药物.set病人身份证号(rs.getString("病人身份证号"));
				过敏药物.set药物名称(rs.getString("药物名称"));
				list.add(过敏药物);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public boolean update(String 病人身份证号, String 药物名称,String 性别, String 联系方式) {
		boolean flag = false;
		DBConn.init();
		String sql ="update 过敏药物 set 药物名称 ='"+药物名称
				+"' where 病人身份证号 = '"+病人身份证号+ "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	public boolean delete(String 病人身份证号, String 药物名称) {
		boolean flag = false;
		DBConn.init();
		String sql = "delete  from 过敏药物 where 病人身份证号= '"+病人身份证号 + "' AND 药物名称 = '" + 药物名称 + "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}

}
