package com.xu.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.xu.entity.zhanghu;
import com.xu.utils.DBConn;

public class zhanghuDao {

    public boolean insert(zhanghu 账户) {
        boolean flag = false;
        DBConn.init();
        int i = DBConn.addUpdDel("insert into zhanghu(账号,密码,管理员工号,账户性质) " +
                "values('" + 账户.get账号() + "','" + 账户.get密码() + "','" + 账户.get管理员工号() + "','" + 账户.get账户性质() + "')");
        if (i > 0) {
            flag = true;
        }
        DBConn.closeConn();
        return flag;
    }

    public boolean login(String 账号, String 密码) {
        boolean flag = false;
        try {
            DBConn.init();
            //SELECT 病人.账号, 密码  FROM 病人, 账户  WHERE 账户.账号 = '2000000006' AND 账户.账号 = 病人.账号;
            ResultSet rs = DBConn.selectSql("SELECT 账号, 密码  FROM zhanghu  WHERE 账号 = '" + 账号 + "'");
            while (rs.next()) {
                if (rs.getString("账号").equals(账号) && rs.getString("密码").equals(密码)) {
                    flag = true;
                }
            }
            DBConn.closeConn();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    public String register(String 密码) {

        DBConn.init();
        ResultSet rs = DBConn.selectSql("select max(账号) as 账号 from zhanghu");
        String h = "0";
        try {
            while (rs.next()) {
                h = rs.getString("账号");
                //System.out.println(h);
                int i = Integer.valueOf(h);
                //System.out.println(i);
                ++i;
                //System.out.println(i);
                h = String.valueOf(i);
                //System.out.println(h);
            }
        } catch (SQLException e) {
            // TODO 自动生成的 catch 块
            e.printStackTrace();
        }
        int i = DBConn.addUpdDel("insert into zhanghu(账号,密码,管理员工号,账户性质) " +
                "values('" + h + "','" + 密码 + "','1000001','3')");
        DBConn.closeConn();
        if (i > 0) {
            return h;
        }
        return h;

    }

    public boolean selectCondition1(String 账号) {
        boolean flag = false;
        try {
            DBConn.init();
            ResultSet rs = DBConn.selectSql("select * from zhanghu where 账号='" + 账号 + "'");
            while (rs.next()) {
                if (rs.getString("账号").equals(账号)) {
                    flag = true;
                }
            }
            DBConn.closeConn();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return flag;
    }

    //根据账号 返回账户性质
    public int judge账户性质(String 账号) {
        int i = 2;
        try {
            DBConn.init();
            ResultSet rs = DBConn.selectSql("select 账户性质 from zhanghu where 账号='" + 账号 + "'");
            if (rs.next()) {
                i = rs.getInt("账户性质");
            }
            DBConn.closeConn();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return i;
    }

    public List<zhanghu> find(String 账户性质) {
        List<zhanghu> list = new ArrayList<zhanghu>();
        String l1 = "";
        if (StringUtils.isBlank(账户性质)) {
            l1 = "账户性质 != '0'";
        } else {
            int 性质 = Integer.valueOf(账户性质);
            l1 = "账户性质 = " + 性质;
        }
        try {
            DBConn.init();
            String sql = "select * from zhanghu where " + l1;
            ResultSet rs = DBConn.selectSql(sql);
            while (rs.next()) {
                zhanghu 账户 = new zhanghu();
                账户.set账号(rs.getString("账号"));
                账户.set密码(rs.getString("密码"));
                账户.set管理员工号(rs.getString("管理员工号"));
                账户.set账户性质(rs.getInt("账户性质"));
                list.add(账户);
            }
            DBConn.closeConn();
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<zhanghu> get账户All() {
        List<zhanghu> list = new ArrayList<zhanghu>();
        try {
            DBConn.init();
            ResultSet rs = DBConn.selectSql("select * from zhanghu");
            while (rs.next()) {
                zhanghu 账户 = new zhanghu();
                账户.set账号(rs.getString("账号"));
                账户.set密码(rs.getString("密码"));
                账户.set管理员工号(rs.getString("管理员工号"));
                账户.set账户性质(rs.getInt("账户性质"));
                list.add(账户);
            }
            DBConn.closeConn();
            return list;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean update(String 账号, String 密码, String 管理员工号, Integer 账户性质) {
        boolean flag = false;
        DBConn.init();
        String sql = "update zhanghu set 密码 ='" + 密码
                + "' , 管理员工号 ='" + 管理员工号
                + "' , 账户性质 ='" + 账户性质
                + "' where 账号 = '" + 账号 + "'";
        int i = DBConn.addUpdDel(sql);
        if (i > 0) {
            flag = true;
        }
        DBConn.closeConn();
        return flag;
    }

    public boolean xiugai(String 账号, String 密码, String 新密码) {
        boolean flag = false;
        DBConn.init();
        ResultSet rs = DBConn.selectSql("SELECT 账号, 密码  FROM zhanghu  WHERE 账号 = '" + 账号 + "'");
        try {
            while (rs.next()) {
                if (rs.getString("账号").equals(账号) && rs.getString("密码").equals(密码)) {
                    String sql = "update zhanghu set 密码 ='" + 新密码
                            + "' where 账号 = '" + 账号 + "'";
                    int i = DBConn.addUpdDel(sql);
                    if (i > 0) {
                        flag = true;
                    }
                }
            }
        } catch (SQLException e) {
            // TODO 自动生成的 catch 块
            e.printStackTrace();
        }
        DBConn.closeConn();
        return flag;
    }

    public boolean delete(String 账号) {
        boolean flag = false;
        DBConn.init();
        String sql = "delete  from zhanghu where 账号= '" + 账号 + "'";
        int i = DBConn.addUpdDel(sql);
        if (i > 0) {
            flag = true;
        }
        DBConn.closeConn();
        return flag;
    }

}
