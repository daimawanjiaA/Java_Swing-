package com.xu.dao;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.xu.entity.bingren;
import com.xu.utils.DBConn;

public class bingrenDao {

	public boolean insert(String 身份证号, String 姓名,String 性别, String 年龄, String 籍贯,String 住址, String 联系方式, String 职业, String 婚姻状况, String 过敏药物, String 既往史,String 账号) {
		boolean flag = false;
		Integer 年纪;
		if(!StringUtils.isBlank(年龄)) {
			年纪 =  Integer.valueOf(年龄);
		}
		else
		{
			年纪 = 0;
		}
		DBConn.init();
		int i =DBConn.addUpdDel("insert into bingren(身份证号) " +
				"values('"+身份证号+"')");
		String sql ="update bingren set 姓名 ='"+姓名
				+"' , 性别 ='"+性别
				+"' , 年龄 ='"+年纪
				+"' , 籍贯 ='"+籍贯
				+"' , 联系方式 ='"+联系方式
				+"' , 住址 ='"+住址
				+"' , 职业 ='"+职业
				+"' , 婚姻状况 ='"+婚姻状况
				+"' , 过敏药物 ='"+过敏药物
				+"' , 既往史 ='"+既往史
				+"' , 账号 ='"+账号
				+"' where 身份证号 = '"+身份证号 + "'";
		int j =DBConn.addUpdDel(sql);
		if(i>0 && j>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	/*
    public boolean login(String 账号, String 密码) {
		boolean flag = false;
		try {
			    DBConn.init();
			    //SELECT 病人.账号, 密码  FROM 病人, 账户  WHERE 账户.账号 = '2000000006' AND 账户.账号 = 病人.账号;
				ResultSet rs = DBConn.selectSql("SELECT 病人.账号, 密码  FROM 病人, 账户  WHERE 账户.账号 = '"+账号+"' AND 账户.账号 = 病人.账号"+"'");
				while(rs.next()){
					if(rs.getString("账号").equals(账号) && rs.getString("密码").equals(密码)){
						flag = true;
					}
				}
				DBConn.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	*/
	public List<bingren> mohu(String 身份证号, String 姓名, String 性别, String 籍贯, String 住址, String 职业, String 婚姻状况) {
		List<bingren> list = new ArrayList<bingren>();
		String l1 = "";
		String l2 = "";
		String l3 = "";
		String l4 = "";
		String l5 = "";
		String l6 = "";
		String l7 = "";
		if(StringUtils.isBlank(身份证号)) {
			l1 = "身份证号 != '00'";
		}
		else {
			l1 = "身份证号 LIKE '"+身份证号+"%'";
		}
		if(StringUtils.isBlank(籍贯)) {
			l2 = "籍贯 != '00'";
		}
		else {
			l2 = "籍贯 LIKE '"+籍贯+"%'";
		}
		if(StringUtils.isBlank(姓名)) {
			l3 = "姓名 != '00'";
		}
		else {
			l3 = "姓名 LIKE '"+姓名+"%'";
		}
		if(StringUtils.isBlank(性别)) {
			l4 = "性别 != '00'";
		}
		else {
			l4 = "性别 = '"+性别+"'";
		}
		if(StringUtils.isBlank(住址)) {
			l5 = "住址 != '00'";
		}
		else {
			l5 = "住址 LIKE '"+住址+"%'";
		}
		if(StringUtils.isBlank(职业)) {
			l6 = "职业 != '00'";
		}
		else {
			l6 = "职业 LIKE '"+职业+"%'";
		}
		if(StringUtils.isBlank(婚姻状况)) {
			l7 = "婚姻状况 != '00'";
		}
		else {
			l7 = "婚姻状况 LIKE '"+婚姻状况+"%'";
		}
		try {
			DBConn.init();
			String sql = "select * from bingren where "+l1+" and "+l2+" and "+l3+" and "+l4+" and "+l5+" and "+l6+" and "+l7;
			ResultSet rs = DBConn.selectSql(sql);

			while(rs.next()){
				bingren 病人 = new bingren();
				病人.set身份证号(rs.getString("身份证号"));
				病人.set过敏药物(rs.getString("过敏药物"));
				病人.set既往史(rs.getString("既往史"));
				病人.set姓名(rs.getString("姓名"));
				病人.set性别(rs.getString("性别"));
				病人.set年龄(rs.getInt("年龄"));
				病人.set籍贯(rs.getString("籍贯"));
				病人.set住址(rs.getString("住址"));
				病人.set联系方式(rs.getString("联系方式"));
				病人.set职业(rs.getString("职业"));
				病人.set婚姻状况(rs.getString("婚姻状况"));
				病人.set账号(rs.getString("账号"));
				list.add(病人);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<bingren> findBy身份证号(String 身份证号) {
		List<bingren> list = new ArrayList<bingren>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from bingren where 身份证号 = '" + 身份证号 + "'");

			while(rs.next()){
				bingren 病人 = new bingren();
				病人.set身份证号(rs.getString("身份证号"));
				病人.set过敏药物(rs.getString("过敏药物"));
				病人.set既往史(rs.getString("既往史"));
				病人.set姓名(rs.getString("姓名"));
				病人.set性别(rs.getString("性别"));
				病人.set年龄(rs.getInt("年龄"));
				病人.set籍贯(rs.getString("籍贯"));
				病人.set住址(rs.getString("住址"));
				病人.set联系方式(rs.getString("联系方式"));
				病人.set职业(rs.getString("职业"));
				病人.set婚姻状况(rs.getString("婚姻状况"));
				病人.set账号(rs.getString("账号"));
				list.add(病人);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public bingren findBy身份证(String 身份证号) {
		bingren 病人 = new bingren();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from bingren where 身份证号 = '" + 身份证号 + "'");

			while(rs.next()){
				病人.set身份证号(rs.getString("身份证号"));
				病人.set过敏药物(rs.getString("过敏药物"));
				病人.set既往史(rs.getString("既往史"));
				病人.set姓名(rs.getString("姓名"));
				病人.set性别(rs.getString("性别"));
				病人.set年龄(rs.getInt("年龄"));
				病人.set籍贯(rs.getString("籍贯"));
				病人.set住址(rs.getString("住址"));
				病人.set联系方式(rs.getString("联系方式"));
				病人.set职业(rs.getString("职业"));
				病人.set婚姻状况(rs.getString("婚姻状况"));
				病人.set账号(rs.getString("账号"));
			}
			DBConn.closeConn();
			return 病人;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public bingren findBy账号(String 账号) {
		bingren 病人 = new bingren();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from bingren where 账号 = '" + 账号 + "'");

			while(rs.next()){

				病人.set身份证号(rs.getString("身份证号"));
				病人.set过敏药物(rs.getString("过敏药物"));
				病人.set既往史(rs.getString("既往史"));
				病人.set姓名(rs.getString("姓名"));
				病人.set性别(rs.getString("性别"));
				病人.set年龄(rs.getInt("年龄"));
				病人.set籍贯(rs.getString("籍贯"));
				病人.set住址(rs.getString("住址"));
				病人.set联系方式(rs.getString("联系方式"));
				病人.set职业(rs.getString("职业"));
				病人.set婚姻状况(rs.getString("婚姻状况"));
				病人.set账号(rs.getString("账号"));
			}
			DBConn.closeConn();
			return 病人;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<bingren> get病人All() {
		List<bingren> list = new ArrayList<bingren>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from bingren");
			while(rs.next()){
				bingren 病人 = new bingren();
				病人.set身份证号(rs.getString("身份证号"));
				病人.set过敏药物(rs.getString("过敏药物"));
				病人.set既往史(rs.getString("既往史"));
				病人.set姓名(rs.getString("姓名"));
				病人.set性别(rs.getString("性别"));
				病人.set年龄(rs.getInt("年龄"));
				病人.set籍贯(rs.getString("籍贯"));
				病人.set住址(rs.getString("住址"));
				病人.set联系方式(rs.getString("联系方式"));
				病人.set职业(rs.getString("职业"));
				病人.set婚姻状况(rs.getString("婚姻状况"));
				病人.set账号(rs.getString("账号"));
				list.add(病人);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public boolean update(String 身份证号, String 姓名,String 性别, Integer 年龄, String 籍贯,String 住址, String 联系方式, String 职业, String 婚姻状况, String 过敏药物, String 既往史) {
		boolean flag = false;
		DBConn.init();
		String sql ="update bingren set 姓名 ='"+姓名
				+"' , 性别 ='"+性别
				+"' , 年龄 ='"+年龄
				+"' , 籍贯 ='"+籍贯
				+"' , 联系方式 ='"+联系方式
				+"' , 住址 ='"+住址
				+"' , 职业 ='"+职业
				+"' , 婚姻状况 ='"+婚姻状况
				+"' , 过敏药物 ='"+过敏药物
				+"' , 既往史 ='"+既往史
				+"' where 身份证号 = '"+身份证号 + "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	public boolean delete(String 身份证号) {
		boolean flag = false;
		DBConn.init();
		String sql = "delete  from bingren where 身份证号= '"+身份证号 + "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
//	public static void main(String[] args) {
//		病人 病人 = new 病人Dao().findBy账号("2000000012");
//		System.out.println(病人.get姓名());
//		System.out.println(病人==null);
//	}
}
