package com.xu.dao;

import java.util.List;
import java.io.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.xu.dao.*;
import com.xu.entity.*;
import com.xu.entity.guanliyuan;
import com.xu.utils.DBConn;

public class Store {
	public void store(List<bingren> list)
	{
		String filename = "D:\\file\\1.txt";
		File file=new File(filename);//我们在该类的位置创建一个新文件
		FileWriter f=null;//创建文件写入对象
		BufferedWriter f1=null;//创建字符流写入对象

		try {
			//这里把文件写入对象和字符流写入对象分开写了
			f=new FileWriter(filename);//创建一个名为cc.txt的文件
			f1=new BufferedWriter(f);
			//通过循环遍历上面的String 数组中的元素

			for (bingren i:list) {
				f1.write("身份证号:  "+i.get身份证号() );
				f1.newLine();//换行操作
				f1.write("姓名:  "+i.get姓名());
				f1.write("    性别:  "+i.get性别());
				f1.write("    年龄:  "+i.get年龄());
				f1.newLine();//换行操作
				f1.write("籍贯:  "+i.get籍贯());
				f1.write("    住址:  "+i.get住址());
				f1.newLine();//换行操作
				f1.write("职业:  "+i.get职业());
				f1.write("    联系方式:  "+i.get联系方式());
				f1.write("    婚姻状况:  "+i.get婚姻状况());
				f1.newLine();//换行操作
				f1.write("过敏药物:  "+i.get过敏药物());
				f1.write("    既往史:  "+i.get既往史());
				f1.newLine();//换行操作
				f1.newLine();//换行操作
				f1.newLine();//换行操作
				f1.newLine();//换行操作
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally {//如果没有catch 异常，程序最终会执行到这里
			try {
				f1.close();
				f.close();//关闭文件
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		//System.out.println("osdvnoisvjoivhoiovw");
	}
	public void resave(String filename)
	{

		//System.out.println("hsdhvsdnv");


		File file1=new File("D:\\file\\1.txt");
		FileReader f2=null;//文件读取对象
		BufferedReader f11=null;//字符流对象


		File file=new File("D:\\AAA\\"+filename+".txt");//我们在该类的位置创建一个新文件
		FileWriter f=null;//创建文件写入对象
		BufferedWriter f1=null;//创建字符流写入对象


		try {
			f=new FileWriter(file);//创建一个名为cc.txt的文件
			f1=new BufferedWriter(f);
			//通过循环遍历上面的String 数组中的元素


			f2=new FileReader(file1);
			f11=new BufferedReader(f2);
			String str="";
			while((str = f11.readLine())!=null) {
				f1.write(str);
				f1.newLine();//换行操作
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally {
			try {
				f11.close();
				f2.close();
				f1.close();
				f.close();//关闭文件
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}

	}

	public void store1(List<jiuzhenjilu> list)
	{
		String filename = "D:\\file\\1.txt";
		File file=new File(filename);//我们在该类的位置创建一个新文件
		FileWriter f=null;//创建文件写入对象
		BufferedWriter f1=null;//创建字符流写入对象

		try {
			//这里把文件写入对象和字符流写入对象分开写了
			f=new FileWriter(filename);//创建一个名为cc.txt的文件
			f1=new BufferedWriter(f);
			//通过循环遍历上面的String 数组中的元素

			for (jiuzhenjilu i:list) {
				f1.write("病人身份证号:  "+i.get病人身份证号() );
				f1.write("    医生工号:  "+i.get医生工号());
				f1.write("    日期:  "+i.get日期());
				f1.newLine();//换行操作
				f1.write("疾病:  "+i.get疾病());
				f1.write("    检查项目:  "+i.get检查项目());
				f1.newLine();//换行操作
				f1.write("症状:  "+i.get症状());
				f1.newLine();//换行操作
				f1.write("医嘱:  "+i.get医嘱());
				f1.newLine();//换行操作
				f1.write("入院时间:  "+i.get入院时间());
				f1.write("    出院时间:  "+i.get出院时间());
				f1.newLine();//换行操作
				f1.write("下次复诊时间:  "+i.get下次复诊时间());
				f1.newLine();//换行操作
				f1.newLine();//换行操作
				f1.newLine();//换行操作
				f1.newLine();//换行操作
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally {//如果没有catch 异常，程序最终会执行到这里
			try {
				f1.close();
				f.close();//关闭文件
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		//System.out.println("osdvnoisvjoivhoiovw");
	}
	public void store2(List<yisheng> list)
	{
		String filename = "D:\\file\\1.txt";
		File file=new File(filename);//我们在该类的位置创建一个新文件
		FileWriter f=null;//创建文件写入对象
		BufferedWriter f1=null;//创建字符流写入对象

		try {
			//这里把文件写入对象和字符流写入对象分开写了
			f=new FileWriter(filename);//创建一个名为cc.txt的文件
			f1=new BufferedWriter(f);
			//通过循环遍历上面的String 数组中的元素

			for (yisheng i:list) {
				f1.write("工号:  "+i.get工号());
				f1.newLine();//换行操作
				f1.write("身份证号:  "+i.get身份证号() );
				f1.newLine();//换行操作
				f1.write("姓名:  "+i.get姓名());
				f1.newLine();//换行操作
				f1.write("性别:  "+i.get性别());
				f1.newLine();//换行操作
				f1.write("联系方式:  "+i.get联系方式());
				f1.newLine();//换行操作

				f1.newLine();//换行操作
				f1.newLine();//换行操作
				f1.newLine();//换行操作
				f1.newLine();//换行操作
			}
		} catch (Exception e) {
			// TODO: handle exception
		}finally {//如果没有catch 异常，程序最终会执行到这里
			try {
				f1.close();
				f.close();//关闭文件
			} catch (Exception e2) {
				// TODO: handle exception
			}
		}
		//System.out.println("osdvnoisvjoivhoiovw");
	}



}
