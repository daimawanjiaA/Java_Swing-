package com.xu.dao;



import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import java.sql.*;

import com.xu.entity.jiuzhenjilu;
import com.xu.utils.DBConn;

public class jiuzhenjiluDao {

	public boolean insert(jiuzhenjilu 就诊记录) {
		boolean flag = false;
		DBConn.init();
		int i =DBConn.addUpdDel("insert into jiuzhenjilu(病人身份证号,医生工号,日期,疾病,症状,检查项目,医嘱,入院时间,出院时间,下次复诊时间) " +
				"values('"+就诊记录.get病人身份证号()+"','"+就诊记录.get医生工号()+"','"+就诊记录.get日期()+"','"+就诊记录.get疾病()+"','"+就诊记录.get症状()+"','"+就诊记录.get检查项目()+"','"+就诊记录.get医嘱()+"','"+就诊记录.get入院时间()+"','"+就诊记录.get出院时间()+"','"+就诊记录.get下次复诊时间()+"')");
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	public boolean selectCondition1(String 病人身份证号, String 医生工号) {
		boolean flag = false;
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from jiuzhenjilu where 病人身份证号='"+病人身份证号+"' and 医生工号='"+医生工号+"'");
			while(rs.next()){
				if(rs.getString("病人身份证号").equals(病人身份证号) && rs.getString("医生工号").equals(医生工号)){
					flag = true;
				}
			}
			DBConn.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	public List<jiuzhenjilu> find( String 病人身份证号, String 医生工号, String 日期1, String 日期2, String 疾病) {
		List<jiuzhenjilu> list = new ArrayList<jiuzhenjilu>();
		String l1 = "";
		String l2 = "";
		String l3 = "";
		String l4 = "";
		String l5 = "";
		String l6 = "";
		String l7 = "";
		if(StringUtils.isBlank(病人身份证号)) {
			l1 = "病人身份证号 != '0'";
		}
		else {
			l1 = "病人身份证号 LIKE '"+病人身份证号+"%'";
		}
		if(StringUtils.isBlank(医生工号)) {
			l2 = "医生工号 != '0'";
		}
		else {
			l2 = "医生工号 LIKE '"+医生工号+"%'";
		}
		if(StringUtils.isBlank(疾病)) {
			l3 = "疾病 != '0'";
		}
		else {
			l3 = "疾病 LIKE '"+疾病+"%'";
		}
		if(StringUtils.isBlank(日期1)&&StringUtils.isBlank(日期2)) {
			l4 = " 日期 != '2000-01-01 00:00:00'" ;
		}
		else if(StringUtils.isBlank(日期1)){
			l4 = " 日期 LIKE '"+日期2+"%'";
		}else if(StringUtils.isBlank(日期2)) {
			l4 = " 日期 LIKE '"+日期1+"%'";
		}else {
			l4 = " 日期 > '"+日期1+"' and 日期 < '"+日期2+"'";
		}
		try {
			DBConn.init();
			String sql = "select * from jiuzhenjilu where "+l1+" and "+l2+" and "+l3+" and "+l4;
			//System.out.println(sql);
			ResultSet rs = DBConn.selectSql(sql);
			while(rs.next()){
				jiuzhenjilu 就诊记录 = new jiuzhenjilu();
				就诊记录.set病人身份证号(rs.getString("病人身份证号"));
				就诊记录.set医生工号(rs.getString("医生工号"));
				就诊记录.set日期(rs.getDate("日期"));
				就诊记录.set疾病(rs.getString("疾病"));
				就诊记录.set症状(rs.getString("症状"));
				就诊记录.set检查项目(rs.getString("检查项目"));
				就诊记录.set医嘱(rs.getString("医嘱"));
				就诊记录.set入院时间(rs.getDate("入院时间"));
				就诊记录.set出院时间(rs.getDate("出院时间"));
				就诊记录.set下次复诊时间(rs.getDate("下次复诊时间"));
				list.add(就诊记录);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("无结果");
		return null;
	}
	public List<jiuzhenjilu> findBy病人(String 病人身份证号) {
		List<jiuzhenjilu> list = new ArrayList<jiuzhenjilu>();
		try {
			DBConn.init();

			ResultSet rs = DBConn.selectSql("select * from jiuzhenjilu where 病人身份证号 = '"+病人身份证号+"'");
			while(rs.next()){
				jiuzhenjilu 就诊记录 = new jiuzhenjilu();
				就诊记录.set病人身份证号(rs.getString("病人身份证号"));
				就诊记录.set医生工号(rs.getString("医生工号"));
				就诊记录.set日期(rs.getDate("日期"));
				就诊记录.set疾病(rs.getString("疾病"));
				就诊记录.set症状(rs.getString("症状"));
				就诊记录.set检查项目(rs.getString("检查项目"));
				就诊记录.set医嘱(rs.getString("医嘱"));
				就诊记录.set入院时间(rs.getDate("入院时间"));
				就诊记录.set出院时间(rs.getDate("出院时间"));
				就诊记录.set下次复诊时间(rs.getDate("下次复诊时间"));
				list.add(就诊记录);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("无结果");
		return null;
	}
	public jiuzhenjilu findBy病人身份证号(String 医生工号, String 病人身份证号, Date 日期) {
		try {
			DBConn.init();
			jiuzhenjilu 就诊记录 = new jiuzhenjilu();
			ResultSet rs = DBConn.selectSql("select * from jiuzhenjilu where 病人身份证号 = '"+病人身份证号+"' AND 医生工号 = '" + 医生工号 + "' AND 日期 = '" + 日期 + "'");
			while(rs.next()){
				就诊记录.set病人身份证号(rs.getString("病人身份证号"));
				就诊记录.set医生工号(rs.getString("医生工号"));
				就诊记录.set日期(rs.getDate("日期"));
				就诊记录.set疾病(rs.getString("疾病"));
				就诊记录.set症状(rs.getString("症状"));
				就诊记录.set检查项目(rs.getString("检查项目"));
				就诊记录.set医嘱(rs.getString("医嘱"));
				就诊记录.set入院时间(rs.getDate("入院时间"));
				就诊记录.set出院时间(rs.getDate("出院时间"));
				就诊记录.set下次复诊时间(rs.getDate("下次复诊时间"));
			}
			DBConn.closeConn();
			return 就诊记录;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("无结果");
		return null;
	}
	//通过日期查找就诊记录，查找当天来就诊的患者
	public List<jiuzhenjilu> findBy日期(Date 日期) {
		List<jiuzhenjilu> list = new ArrayList<jiuzhenjilu>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from jiuzhenjilu where date_format(日期, '%Y-%m-%d') = '"+日期+"'");
			while(rs.next()){
				jiuzhenjilu 就诊记录 = new jiuzhenjilu();
				就诊记录.set病人身份证号(rs.getString("病人身份证号"));
				就诊记录.set医生工号(rs.getString("医生工号"));
				就诊记录.set日期(rs.getDate("日期"));
				就诊记录.set疾病(rs.getString("疾病"));
				就诊记录.set症状(rs.getString("症状"));
				就诊记录.set检查项目(rs.getString("检查项目"));
				就诊记录.set医嘱(rs.getString("医嘱"));
				就诊记录.set入院时间(rs.getDate("入院时间"));
				就诊记录.set出院时间(rs.getDate("出院时间"));
				就诊记录.set下次复诊时间(rs.getDate("下次复诊时间"));
				list.add(就诊记录);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("无结果");
		return null;
	}
	//查询两个日期之间的就诊记录
	public List<jiuzhenjilu> findBy日期(Date 日期1, Date 日期2) {
		List<jiuzhenjilu> list = new ArrayList<jiuzhenjilu>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from jiuzhenjilu where date_format(日期, '%Y-%m-%d') between '"+日期1+"' AND '" +日期2 +"'");
			while(rs.next()){
				jiuzhenjilu 就诊记录 = new jiuzhenjilu();
				就诊记录.set病人身份证号(rs.getString("病人身份证号"));
				就诊记录.set医生工号(rs.getString("医生工号"));
				就诊记录.set日期(rs.getDate("日期"));
				就诊记录.set疾病(rs.getString("疾病"));
				就诊记录.set症状(rs.getString("症状"));
				就诊记录.set检查项目(rs.getString("检查项目"));
				就诊记录.set医嘱(rs.getString("医嘱"));
				就诊记录.set入院时间(rs.getDate("入院时间"));
				就诊记录.set出院时间(rs.getDate("出院时间"));
				就诊记录.set下次复诊时间(rs.getDate("下次复诊时间"));
				list.add(就诊记录);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		System.out.println("无结果");
		return null;
	}
	public List<jiuzhenjilu> get就诊记录All() {
		List<jiuzhenjilu> list = new ArrayList<jiuzhenjilu>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from jiuzhenjilu");
			while(rs.next()){
				jiuzhenjilu 就诊记录 = new jiuzhenjilu();
				就诊记录.set病人身份证号(rs.getString("病人身份证号"));
				就诊记录.set医生工号(rs.getString("医生工号"));
				就诊记录.set日期(rs.getDate("日期"));
				就诊记录.set疾病(rs.getString("疾病"));
				就诊记录.set症状(rs.getString("症状"));
				就诊记录.set检查项目(rs.getString("检查项目"));
				就诊记录.set医嘱(rs.getString("医嘱"));
				就诊记录.set入院时间(rs.getDate("入院时间"));
				就诊记录.set出院时间(rs.getDate("出院时间"));
				就诊记录.set下次复诊时间(rs.getDate("下次复诊时间"));
				list.add(就诊记录);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public boolean update(jiuzhenjilu 就诊记录) {
		boolean flag = false;
		DBConn.init();
		String sql ="update jiuzhenjilu set 疾病 ='"+就诊记录.get疾病()
				+"' , 症状 ='"+就诊记录.get症状()
				+"' , 医嘱 ='"+就诊记录.get医嘱()
				+"' , 检查项目 ='"+就诊记录.get检查项目()
				+"' , 入院时间 ='"+就诊记录.get入院时间()
				+"' , 出院时间 ='"+就诊记录.get出院时间()
				+"' , 下次复诊时间 ='"+就诊记录.get下次复诊时间()
				+"' where 病人身份证号 = '"+就诊记录.get病人身份证号()+ "' AND 医生工号 = '"+就诊记录.get医生工号()+ "' AND 日期 = '" + 就诊记录.get日期() + "'";

		// UPDATE 就诊记录 SET 医生工号 = '21830', 日期= '2014', 疾病 = '感冒' where 病人身份证号 = '32570280' AND 医生工号 = '49874917'
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	public boolean delete(String 病人身份证号, String 医生工号) {
		boolean flag = false;
		DBConn.init();
		String sql = "delete  from jiuzhenjilu where 病人身份证号= '"+病人身份证号 + "' AND 医生工号 = '" + 医生工号 + "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}

}
