package com.xu.dao;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.xu.entity.guanliyuan;
import com.xu.utils.DBConn;

public class guanliyuanDao {

	public boolean insert(guanliyuan 管理员) {
		boolean flag = false;
		DBConn.init();
		int i =DBConn.addUpdDel("insert into guanliyuan(工号,姓名,性别,联系方式) " +
				"values('"+管理员.get工号()+"','"+管理员.get姓名()+"','"+管理员.get性别()+"','"+管理员.get联系方式()+"')");
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	/*
    public boolean login(String 账号, String 密码) {
		boolean flag = false;
		try {
			    DBConn.init();
			    //SELECT 病人.账号, 密码  FROM 病人, 账户  WHERE 账户.账号 = '2000000006' AND 账户.账号 = 病人.账号;
				ResultSet rs = DBConn.selectSql("SELECT 管理员.账号, 密码  FROM 病人, 账户  WHERE 账户.账号 = '"+账号+"' AND 账户.账号 = 管理员.账号"+"'");
				while(rs.next()){
					if(rs.getString("账号").equals(账号) && rs.getString("密码").equals(密码)){
						flag = true;
					}
				}
				DBConn.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
    */
	public boolean selectCondition1(String 工号) {
		boolean flag = false;
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from guanliyuan where 工号='"+工号+"'");
			while(rs.next()){
				if(rs.getString("工号").equals(工号)){
					flag = true;
				}
			}
			DBConn.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	public List<guanliyuan> get管理员All() {
		List<guanliyuan> list = new ArrayList<guanliyuan>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from guanliyuan");
			while(rs.next()){
				guanliyuan 管理员 = new guanliyuan();
				管理员.set工号(rs.getString("工号"));
				管理员.set姓名(rs.getString("姓名"));
				管理员.set性别(rs.getString("性别"));
				管理员.set联系方式(rs.getString("联系方式"));
				list.add(管理员);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public boolean update(String 工号, String 姓名,String 性别, String 联系方式) {
		boolean flag = false;
		DBConn.init();
		String sql ="update guanliyuan set 姓名 ='"+姓名
				+"' , 性别 ='"+性别
				+"' , 联系方式 ='"+联系方式
				+"' where 工号 = '"+工号+ "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	public boolean delete(String 工号) {
		boolean flag = false;
		DBConn.init();
		String sql = "delete  from guanliyuan where 工号= '"+工号 + "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}

}
