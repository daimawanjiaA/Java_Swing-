package com.xu.dao;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.xu.entity.yisheng;
import com.xu.utils.DBConn;

public class yishengDao {

	public boolean insert2(String 工号,String 姓名,String 性别,String 身份证号,String 联系方式) {
		boolean flag = false;
		DBConn.init();
		int i =DBConn.addUpdDel("insert into yisheng(工号,姓名,性别,身份证号,联系方式) " +
				"values('"+工号+"','"+姓名+"','"+性别+"','"+身份证号+"','"+联系方式+"')");
		//update 医生 set 账号 = 工号 where 工号 = '1824103001';
		int j = DBConn.addUpdDel("update 医生 set 账号 = 工号 where 工号 = '" + 工号 +"'");
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}


	public boolean insert(yisheng 医生) {
		boolean flag = false;
		DBConn.init();
		int i =DBConn.addUpdDel("insert into yisheng(工号,姓名,性别,身份证号,联系方式,账号) " +
				"values('"+医生.get工号()+"','"+医生.get姓名()+"','"+医生.get性别()+"','"+医生.get身份证号()+"','"+医生.get联系方式()+"','"+医生.get账号()+"')");
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	public boolean selectCondition1(String 工号, String 姓名) {
		boolean flag = false;
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from yisheng where 工号='"+工号+"' and 姓名='"+姓名+"'");
			while(rs.next()){
				if(rs.getString("工号").equals(工号) && rs.getString("姓名").equals(姓名)){
					flag = true;
				}
			}
			DBConn.closeConn();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}
	public List<yisheng> find(String 工号,String 身份证号, String 姓名,String 性别) {
		List<yisheng> list = new ArrayList<yisheng>();
		String l1 = "";
		String l2 = "";
		String l3 = "";
		String l4 = "";
		if(StringUtils.isBlank(工号)) {
			l1 = "工号 != '0'";
		}
		else {
			l1 = "工号 LIKE '"+工号+"%'";
		}
		if(StringUtils.isBlank(身份证号)) {
			l2 = "身份证号 != '0'";
		}
		else {
			l2 = "身份证号 LIKE '"+身份证号+"%'";
		}
		if(StringUtils.isBlank(姓名)) {
			l3 = "姓名 != '0'";
		}
		else {
			l3 = "姓名 LIKE '"+姓名+"%'";
		}
		if(StringUtils.isBlank(性别)) {
			l4 = "性别 != '无'";
		}
		else {
			l4 = "性别 = '"+性别+"'";
		}
		try {
			DBConn.init();
			String sql = "select * from yisheng where "+l1+" and "+l2+" and "+l3+" and "+l4;
			ResultSet rs = DBConn.selectSql(sql);
			while(rs.next()){
				yisheng 医生 = new yisheng();
				医生.set工号(rs.getString("工号"));
				医生.set姓名(rs.getString("姓名"));
				医生.set性别(rs.getString("性别"));
				医生.set身份证号(rs.getString("身份证号"));
				医生.set联系方式(rs.getString("联系方式"));
				医生.set账号(rs.getString("账号"));
				list.add(医生);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<yisheng> get医生All() {
		List<yisheng> list = new ArrayList<yisheng>();
		try {
			DBConn.init();
			ResultSet rs = DBConn.selectSql("select * from yisheng");
			while(rs.next()){
				yisheng 医生 = new yisheng();
				医生.set工号(rs.getString("工号"));
				医生.set姓名(rs.getString("姓名"));
				医生.set性别(rs.getString("性别"));
				医生.set身份证号(rs.getString("身份证号"));
				医生.set联系方式(rs.getString("联系方式"));
				医生.set账号(rs.getString("账号"));
				list.add(医生);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public List<yisheng> findBy姓名(String 姓名) {
		List<yisheng> list = new ArrayList<yisheng>();
		try {
			DBConn.init();
			//System.out.println("select * from 医生 where 姓名 LIKE '" + 姓名 +"%'");
			ResultSet rs = DBConn.selectSql("select * from yisheng where 姓名 LIKE '" + 姓名 +"%'");
			while(rs.next()){
				yisheng 医生 = new yisheng();
				医生.set工号(rs.getString("工号"));
				医生.set姓名(rs.getString("姓名"));
				医生.set性别(rs.getString("性别"));
				医生.set身份证号(rs.getString("身份证号"));
				医生.set联系方式(rs.getString("联系方式"));
				医生.set账号(rs.getString("账号"));
				list.add(医生);
			}
			DBConn.closeConn();
			return list;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	public boolean update(String 工号, String 姓名,String 性别, String 身份证号,String 联系方式) {
		boolean flag = false;
		DBConn.init();
		String sql ="update yisheng set 姓名 ='"+姓名
				+"' , 性别 ='"+性别
				+"' , 身份证号 ='"+身份证号
				+"' , 联系方式 ='"+联系方式
				+"' where 工号 = '"+工号 + "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}
	public boolean delete(String 工号) {
		boolean flag = false;
		DBConn.init();
		String sql = "delete  from yisheng where 工号= '"+工号 + "'";
		int i =DBConn.addUpdDel(sql);
		if(i>0){
			flag = true;
		}
		DBConn.closeConn();
		return flag;
	}

}
