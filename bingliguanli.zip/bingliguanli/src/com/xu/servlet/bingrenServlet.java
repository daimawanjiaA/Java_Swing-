package com.xu.servlet;
import com.xu.dao.*;
import com.xu.entity.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

@WebServlet("/bingren")
public class bingrenServlet extends HttpServlet{


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO 自动生成的方法存根

		doPost(req,resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO 自动生成的方法存根
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
		if("list".equals(method)) {
			this.list(request, response);
		}else if("add".equals(method)) {
			this.add(request, response);
		}else if("edit".equals(method)) {
			this.find(request, response);
		}else if("editsubmit".equals(method)) {
			this.editsubmit(request, response);
		}else if("look".equals(method)) {
			this.look(request, response);
		}
		else if("condition".equals(method)) {
			this.condition(request, response);
		}else if("self".equals(method)) {
			this.self(request, response);
		}
		else if("mohu".equals(method)) {
			this.mohu(request, response);
		}
	}
	private void list(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<bingren> list = new bingrenDao().get病人All();
			new Store().store(list);
			request. setAttribute("list",list);
			request. getRequestDispatcher("page/bingren/list.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void mohu(HttpServletRequest request, HttpServletResponse response) {
		try {
			String 身份证号 = request.getParameter("shenfenzhenghao");
			String 姓名 = request.getParameter("xingming");
			String 性别 = request.getParameter("xingbie");
			String 籍贯 = request.getParameter("jiguan");
			String 住址 = request.getParameter("zhuzhi");
			String 职业 = request.getParameter("zhiye");
			String 婚姻状况 = request.getParameter("hunyin");
			List<bingren> list = new bingrenDao().mohu(身份证号, 姓名, 性别, 籍贯, 住址, 职业, 婚姻状况);
			new Store().store(list);
			request. setAttribute("list",list);
			request. getRequestDispatcher("page/bingren/list.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void self(HttpServletRequest request, HttpServletResponse response) {
		try {
			String 账号 = request.getParameter("userName");
			bingren 病人 = new bingrenDao().findBy账号(账号);
			//System.out.println(病人.get身份证号());
			if(病人.get身份证号()==null)
			{
				request.setAttribute("账号",账号);
				request.getRequestDispatcher("page/bingren/add.jsp").forward(request, response);
			}else {
				request.setAttribute("病人",病人);
				request.getRequestDispatcher("page/bingren/update.jsp").forward(request, response);
			}
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}

	private void condition(HttpServletRequest request, HttpServletResponse response) {
		try {
			String 病人身份证号 = request.getParameter("bingrenid");

			bingren 病人 = new bingrenDao().findBy身份证(病人身份证号);
			request.setAttribute("病人",病人);
			request.getRequestDispatcher("page/bingren/look.jsp").forward(request, response);

		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}

	private void add(HttpServletRequest request, HttpServletResponse response) {
		String 身份证号 = request.getParameter("id");
		/*
		System.out.println(request.getParameter("id"));
		System.out.println(医生工号);
		*/
		String 姓名 = request.getParameter("xingming");
		String 性别 = request.getParameter("xingbie");
		String 年龄 = request.getParameter("nianling");
		String 籍贯 = request.getParameter("jiguan");
		String 住址 = request.getParameter("zhuzhi");
		String 联系方式 = request.getParameter("lianxi");
		String 职业 = request.getParameter("zhiye");
		String 婚姻状况 = request.getParameter("hunyin");
		String 既往史 = request.getParameter("jiwangshi");
		String 过敏药物 = request.getParameter("guomin");
		String 账号 = request.getParameter("zhanghao");
		//System.out.println(账号);
		try {
			new bingrenDao().insert(身份证号, 姓名, 性别, 年龄, 籍贯, 住址, 联系方式, 职业, 婚姻状况, 过敏药物, 既往史, 账号);
			response.sendRedirect("bingren?method=list");
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void find(HttpServletRequest request, HttpServletResponse response) {
		Date 日期 =  Date.valueOf(request.getParameter("riqi"));
		String 病人身份证号 = request.getParameter("bingrenid");
		String 医生工号 = request.getParameter("yishenid");
		try {
			jiuzhenjilu 就诊记录 = new jiuzhenjiluDao().findBy病人身份证号(医生工号, 病人身份证号, 日期);
			request.setAttribute("就诊记录", 就诊记录);
			request.getRequestDispatcher("page/bingren/update.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void editsubmit(HttpServletRequest request, HttpServletResponse response) {
		bingren a = new bingren();
		String 身份证号 = request.getParameter("id");
		/*
		System.out.println(request.getParameter("id"));
		System.out.println(医生工号);
		*/
		String 姓名 = request.getParameter("xingming");
		String 性别 = request.getParameter("xingbie");
		int 年龄 = Integer.valueOf(request.getParameter("nianling"));
		String 籍贯 = request.getParameter("jiguan");
		String 住址 = request.getParameter("zhuzhi");
		String 联系方式 = request.getParameter("lianxi");
		String 职业 = request.getParameter("zhiye");
		String 婚姻状况 = request.getParameter("hunyin");
		String 过敏药物 = request.getParameter("guomin");
		String 既往史 = request.getParameter("jiwangshi");
		try {
			new bingrenDao().update(身份证号, 姓名, 性别, 年龄, 籍贯, 住址, 联系方式, 职业, 婚姻状况,过敏药物,既往史);
			response.sendRedirect("bingren?method=list");
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void look(HttpServletRequest request, HttpServletResponse response) {

		String 病人身份证号 = request.getParameter("bingrenid");

		try {
			bingren 病人 = new bingrenDao().findBy身份证(病人身份证号);
			request.setAttribute("病人",病人 );
			request.getRequestDispatcher("page/bingren/look.jsp").forward(request, response);

		} catch (Exception e) {
			e. printStackTrace();
		}
	}
}
