package com.xu.servlet;
import com.xu.dao.*;
import com.xu.entity.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

@WebServlet("/zhanghu")
public class zhanghuServlet extends HttpServlet{


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO 自动生成的方法存根

		doPost(req,resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO 自动生成的方法存根
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
		if("list".equals(method)) {
			this.list(request, response);
		}else if("add".equals(method)) {
			this.add(request, response);
		}else if("edit".equals(method)) {
			this.find(request, response);
		}else if("editsubmit".equals(method)) {
			this.editsubmit(request, response);
		}else if("look".equals(method)) {
			this.look(request, response);
		}
		else if("condition".equals(method)) {
			this.condition(request, response);
		}
		else if("mohu".equals(method)) {
			this.mohu(request, response);
		}
	}
	private void list(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<zhanghu> list = new zhanghuDao().get账户All();
			request. setAttribute("list",list);
			request. getRequestDispatcher("page/zhanghu/list.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void mohu(HttpServletRequest request, HttpServletResponse response) {
		try {
			String 账户性质 = request.getParameter("xingzhi");
			//System.out.println(账户性质);
			List<zhanghu> list = new zhanghuDao().find(账户性质);
			request. setAttribute("list",list);
			request. getRequestDispatcher("page/zhanghu/list.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void condition(HttpServletRequest request, HttpServletResponse response) {
		try {
			String 病人身份证号 = request.getParameter("bingrenid");
			bingren 病人 = new bingrenDao().findBy身份证(病人身份证号);
			request.setAttribute("病人",病人);
			request.getRequestDispatcher("page/bingren/look.jsp").forward(request, response);

		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}

	private void add(HttpServletRequest request, HttpServletResponse response) {
		jiuzhenjilu a = new jiuzhenjilu();
		String 医生工号 = request.getParameter("yishenid");
		String 病人身份证号 = request.getParameter("bingrenid");

		String 疾病 = request.getParameter("jibing");
		String 症状 = request.getParameter("zhengzhuang");
		String 医嘱 = request.getParameter("yizhu");
		String 检查项目 = request.getParameter("jianchaxiangmu");
		a.set医生工号(医生工号);
		a.set症状(症状);
		if(!StringUtils.isBlank(request.getParameter("chuyuan"))) {
			Date 出院时间 =  Date.valueOf(request.getParameter("chuyuan"));
			a.set出院时间(出院时间);
		}
		else
		{
			Date 出院时间 =  Date.valueOf("2000-01-01");
			a.set出院时间(出院时间);
		}
		a.set病人身份证号(病人身份证号);
		a.set疾病(疾病);
		a.set检查项目(检查项目);
		a.set医嘱(医嘱);
		if(!StringUtils.isBlank(request.getParameter("ruyuan"))) {
			Date 入院时间 =  Date.valueOf(request.getParameter("ruyuan"));
			a.set入院时间(入院时间);
		}
		else
		{
			Date 入院时间 =  Date.valueOf("2000-01-01 00:00:01");
			a.set入院时间(入院时间);
		}
		if(!StringUtils.isBlank(request.getParameter("riqi"))) {
			Date 日期 =  Date.valueOf(request.getParameter("riqi"));
			a.set日期(日期);
		}
		else {
			Date 日期 =  Date.valueOf("2000-01-01 00:00:01");
			a.set日期(日期);
		}
		if(!StringUtils.isBlank(request.getParameter("xiaci"))) {
			Date 下次复诊时间 = Date.valueOf(request.getParameter("xiaci"));
			a.set下次复诊时间(下次复诊时间);
		}
		else {
			Date 下次复诊时间 = Date.valueOf("2000-01-01");
			a.set下次复诊时间(下次复诊时间);
		}

/*
			Date 入院时间 =  Date.valueOf(request.getParameter("ruyuan"));
			a.set入院时间(入院时间);


			Date 日期 =  Date.valueOf(request.getParameter("riqi"));
			a.set日期(日期);
			System.out.println(日期);


			Date 下次复诊时间 = Date.valueOf(request.getParameter("xiaci"));
			a.set下次复诊时间(下次复诊时间);
	*/
		try {
			new jiuzhenjiluDao().insert(a);
			response.sendRedirect("bingren?method=list");
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void find(HttpServletRequest request, HttpServletResponse response) {
		String 账号 = request.getParameter("zhanghao");

		try {
//			就诊记录 就诊记录 = new 就诊记录Dao().findBy病人身份证号(医生工号, 病人身份证号, 日期);
//			request.setAttribute("就诊记录", 就诊记录);
			request.setAttribute("账号", 账号);
			request.getRequestDispatcher("page/zhanghu/update.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void editsubmit(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String 账号 = request.getParameter("zhanghao");
		String 密码 = request.getParameter("yuan");
		String 新密码 = request.getParameter("xin");
		String 确认密码 = request.getParameter("queren");

		if (新密码.equals(确认密码)) {
			try {
				boolean i = new zhanghuDao().xiugai(账号, 密码, 新密码);
				if(i) {
					request.setAttribute("账号",账号);
					request.setAttribute("error", "修改成功！");
					request.getRequestDispatcher("page/zhanghu/update.jsp").forward(request, response);
				}
				else {
					request.setAttribute("账号",账号);
					request.setAttribute("error", "密码错误！");
					request.getRequestDispatcher("page/zhanghu/update.jsp").forward(request, response);
				}
			} catch (IOException e) {
				e. printStackTrace();
			}
		}
		else {
			request.setAttribute("账号",账号);
			request.setAttribute("error", "两次密码不一致！");
			request.getRequestDispatcher("page/zhanghu/update.jsp").forward(request, response);
		}

	}
	private void look(HttpServletRequest request, HttpServletResponse response) {

		String 病人身份证号 = request.getParameter("bingrenid");

		try {
			bingren 病人 = new bingrenDao().findBy身份证(病人身份证号);
			request.setAttribute("病人",病人 );
			request.getRequestDispatcher("page/bingren/look.jsp").forward(request, response);

		} catch (Exception e) {
			e. printStackTrace();
		}
	}
}
