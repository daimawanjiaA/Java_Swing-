package com.xu.servlet;

import java.io.IOException;
import java.sql.SQLException;

import com.xu.dao.*;
import com.xu.entity.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        String userName = req.getParameter("userName");//获得用户名
        String password = req.getParameter("password");//获得密码
        String validatecode = req.getParameter("validatecode");
        String syscode = req.getParameter("syscode");

        if (StringUtils.isBlank(password) || StringUtils.isBlank(userName)) {
            req.setAttribute("error", "输入信息不能为空！");
            req.getRequestDispatcher("login.jsp").forward(req, resp);
        }
        if (StringUtils.isBlank(validatecode)) {
            req.setAttribute("error", "验证码不能为空！");
            req.getRequestDispatcher("login.jsp").forward(req, resp);
        }
        if (!validatecode.equals(syscode)) {
            req.setAttribute("error", "验证码错误");
            req.getRequestDispatcher("login.jsp").forward(req, resp);
        }
        zhanghuDao z = new zhanghuDao();
        int a = 0;
        a = z.judge账户性质(userName);

        String type;
        //判断账号密码是否正确
        boolean flag = new zhanghuDao().login(userName, password);
        if (flag == true) {
            //执行跳转
            if (a == 1) {
                session.setAttribute("type", "1");
                session.setAttribute("userName", userName);
                req.getRequestDispatcher("index.jsp").forward(req, resp);
            } else if (a == 2) {
                session.setAttribute("type", "2");
                session.setAttribute("userName", userName);
                req.getRequestDispatcher("index.jsp").forward(req, resp);
            } else if (a == 3) {
                session.setAttribute("type", "3");
                session.setAttribute("userName", userName);
                req.getRequestDispatcher("index.jsp").forward(req, resp);
            }
        } else {
            //用户或密码错误
            req.setAttribute("error", "用户名或密码错误！");
            req.getRequestDispatcher("login.jsp").forward(req, resp);
        }

    }
}