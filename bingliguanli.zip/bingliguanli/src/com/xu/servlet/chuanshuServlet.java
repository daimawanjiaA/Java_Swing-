package com.xu.servlet;
import com.xu.dao.*;
import com.xu.entity.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

@WebServlet("/chuanshu")
public class chuanshuServlet extends HttpServlet{


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO 自动生成的方法存根

		doPost(req,resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO 自动生成的方法存根
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
		if("list".equals(method)) {
			this.list(request, response);
		}else if("yishengid".equals(method)) {
			this.id(request, response);
		}else if("yi".equals(method)) {
			this.yi(request, response);
		}else if("jiuzhen".equals(method)) {
			this.jiuzhen(request, response);
		}
		else if("bingren".equals(method)) {
			this.bingren(request, response);
		}
		else if("save".equals(method)) {
			this.save(request, response);
		}else if("yisheng".equals(method)) {
			this.yisheng(request, response);
		}
	}
	private void list(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<jiuzhenjilu> list = new jiuzhenjiluDao().get就诊记录All();
			request.setAttribute("list",list);
			request.getRequestDispatcher("page/jiuzhenjilu/list.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}

	private void id(HttpServletRequest request, HttpServletResponse response) {
		try {
			String id = request.getParameter("id");
			//System.out.println(request.getParameter("id"));
			request.setAttribute("id",id);
			request.getRequestDispatcher("page/jiuzhenjilu/add.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}

	private void yi(HttpServletRequest request, HttpServletResponse response) {
		try {
			String id = request.getParameter("id");
			//System.out.println(request.getParameter("id"));
			request.setAttribute("id",id);
			request.getRequestDispatcher("page/jiuzhenjilu/yishenglist.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void jiuzhen(HttpServletRequest request, HttpServletResponse response) {
		String file = request.getParameter("file");
		//String filename = request.getParameter("filename");
		System.out.println(file);
		System.out.println("list");
		new Store().resave(file);
	}

	private void yisheng(HttpServletRequest request, HttpServletResponse response) {
		String file = request.getParameter("file");
		//String filename = request.getParameter("filename");
		System.out.println(file);
		System.out.println("list");
		new Store().resave(file);
	}
	private void bingren(HttpServletRequest request, HttpServletResponse response) {
		String file = request.getParameter("file");
		//String filename = request.getParameter("filename");
		System.out.println(file);
		System.out.println("list");
		new Store().resave(file);
	}
	private void save(HttpServletRequest request, HttpServletResponse response) {
//		try {
		String file = request.getParameter("file");
		//String filename = request.getParameter("filename");
		System.out.println(file);
		System.out.println("list");
		new Store().resave(file);
		//request.setAttribute("id",id);
		//request.getRequestDispatcher("").forward(request, response);
//		} catch (ServletException e) {
//			// TODO Auto-generated catch block
//			e. printStackTrace();
//			 } catch (IOException e) {
//				e. printStackTrace();
//			}
	}
}
