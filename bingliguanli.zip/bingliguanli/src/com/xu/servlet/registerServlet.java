package com.xu.servlet;
import java.io.IOException;
import java.sql.SQLException;

import com.xu.dao.*;
import com.xu.entity.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

@WebServlet("/register")
public class registerServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String userName = req.getParameter("userName");//获得用户名
		String password = req.getParameter("password");//获得密码
		String queren = req.getParameter("queren");
		if (StringUtils.isBlank(password)||StringUtils.isBlank(queren)) {
			req.setAttribute("error", "输入信息不能为空！");
			req.getRequestDispatcher("register.jsp").forward(req, resp);
		}
		if(!password.equals(queren)) {
			req.setAttribute("error", "两次密码不一致");
			req.getRequestDispatcher("register.jsp").forward(req, resp);
		}
		zhanghuDao z = new zhanghuDao();
		String a = z.register(password);

		HttpSession session = req.getSession();
		//判断账号密码是否正确
		if(a != "0") {
			req.setAttribute("userName", a);
			req.setAttribute("error", "注册成功！");
			req.getRequestDispatcher("success.jsp").forward(req, resp);
		}
		else{
			req.setAttribute("error", "注册失败！");
			req.getRequestDispatcher("register.jsp").forward(req, resp);
		}

	}
}