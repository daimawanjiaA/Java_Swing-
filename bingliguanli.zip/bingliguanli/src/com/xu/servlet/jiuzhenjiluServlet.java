package com.xu.servlet;
import com.xu.dao.*;
import com.xu.entity.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;

@WebServlet("/jiuzhenjilu")
public class jiuzhenjiluServlet extends HttpServlet{


	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO 自动生成的方法存根

		doPost(req,resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO 自动生成的方法存根
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		String method = request.getParameter("method");
		if("list".equals(method)) {
			this.list(request, response);
		}else if("add".equals(method)) {
			this.add(request, response);
		}else if("edit".equals(method)) {
			this.find(request, response);
		}else if("editsubmit".equals(method)) {
			this.editsubmit(request, response);
		}else if("look".equals(method)) {
			this.look(request, response);
		}else if("condition".equals(method)) {
			this.condition(request, response);
		}else if("self".equals(method)) {
			this.self(request, response);
		}
		else if("mohu".equals(method)) {
			this.mohu(request, response);
		}
	}
	private void list(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<jiuzhenjilu> list = new jiuzhenjiluDao().get就诊记录All();
			new Store().store1(list);
			request.setAttribute("list",list);
			request.getRequestDispatcher("page/jiuzhenjilu/list.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}

	private void mohu(HttpServletRequest request, HttpServletResponse response) {
		try {
			String 医生工号 = request.getParameter("yishengid");
			String 病人身份证号 = request.getParameter("bingrenid");
			String 疾病 = request.getParameter("jibing");
			String 日期1 =  request.getParameter("riqi1");
			String 日期2 =  request.getParameter("riqi2");
			List<jiuzhenjilu> list = new jiuzhenjiluDao().find(病人身份证号, 医生工号, 日期1, 日期2, 疾病);
			new Store().store1(list);
			request.setAttribute("list",list);
			request.getRequestDispatcher("page/jiuzhenjilu/list.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}

	private void condition(HttpServletRequest request, HttpServletResponse response) {
		try {
			String 病人身份证号 = request.getParameter("bingrenid");
			String 医生工号 = request.getParameter("gonghao");
			List<jiuzhenjilu> list = new jiuzhenjiluDao().findBy病人(病人身份证号);
			new Store().store1(list);
			request.setAttribute("id",医生工号);
			request.setAttribute("list",list);
			request.getRequestDispatcher("page/jiuzhenjilu/list.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void self(HttpServletRequest request, HttpServletResponse response) {
		try {
			String 账号 = request.getParameter("userName");
			bingren 病人 = new bingrenDao().findBy账号(账号);
			String 病人身份证号 = 病人.get身份证号();
			List<jiuzhenjilu> list = new jiuzhenjiluDao().findBy病人(病人身份证号);
			new Store().store1(list);
			request.setAttribute("list",list);
			request.getRequestDispatcher("page/jiuzhenjilu/list.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}

	private void add(HttpServletRequest request, HttpServletResponse response) {
		jiuzhenjilu a = new jiuzhenjilu();
		String 医生工号 = request.getParameter("yishengid");

		String 病人身份证号 = request.getParameter("bingrenid");

		String 疾病 = request.getParameter("jibing");
		String 症状 = request.getParameter("zhengzhuang");
		String 医嘱 = request.getParameter("yizhu");
		String 检查项目 = request.getParameter("jianchaxiangmu");
		a.set医生工号(医生工号);
		a.set症状(症状);
		if(!StringUtils.isBlank(request.getParameter("chuyuan"))) {
			Date 出院时间 =  Date.valueOf(request.getParameter("chuyuan"));
			a.set出院时间(出院时间);
		}
		else
		{
			Date 出院时间 =  Date.valueOf("2000-01-01");
			a.set出院时间(出院时间);
		}
		a.set病人身份证号(病人身份证号);
		a.set疾病(疾病);
		a.set检查项目(检查项目);
		a.set医嘱(医嘱);
		if(!StringUtils.isBlank(request.getParameter("ruyuan"))) {
			Date 入院时间 =  Date.valueOf(request.getParameter("ruyuan"));
			a.set入院时间(入院时间);
		}
		else
		{
			Date 入院时间 =  Date.valueOf("2000-01-01");
			a.set入院时间(入院时间);
		}
		if(!StringUtils.isBlank(request.getParameter("riqi"))) {
			Date 日期 =  Date.valueOf(request.getParameter("riqi"));
			a.set日期(日期);
		}
		else {
			Date 日期 =  Date.valueOf("2000-01-01");
			a.set日期(日期);
		}
		if(!StringUtils.isBlank(request.getParameter("xiaci"))) {
			Date 下次复诊时间 = Date.valueOf(request.getParameter("xiaci"));
			a.set下次复诊时间(下次复诊时间);
		}
		else {
			Date 下次复诊时间 = Date.valueOf("2000-01-01");
			a.set下次复诊时间(下次复诊时间);
		}

/*
			Timestamp 入院时间 =  Timestamp.valueOf(request.getParameter("ruyuan"));
			a.set入院时间(入院时间);


			Timestamp 日期 =  Timestamp.valueOf(request.getParameter("riqi"));
			a.set日期(日期);
			System.out.println(日期);


			Date 下次复诊时间 = Date.valueOf(request.getParameter("xiaci"));
			a.set下次复诊时间(下次复诊时间);
	*/
		try {
			new jiuzhenjiluDao().insert(a);
			response.sendRedirect("jiuzhenjilu?method=list");
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void find(HttpServletRequest request, HttpServletResponse response) {
		Date 日期 =  Date.valueOf(request.getParameter("riqi"));
		String 病人身份证号 = request.getParameter("bingrenid");
		String 医生工号 = request.getParameter("yishenid");
		try {
			jiuzhenjilu 就诊记录 = new jiuzhenjiluDao().findBy病人身份证号(医生工号, 病人身份证号, 日期);
			request.setAttribute("就诊记录", 就诊记录);
			request.getRequestDispatcher("page/jiuzhenjilu/update.jsp").forward(request, response);
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void editsubmit(HttpServletRequest request, HttpServletResponse response) {
		jiuzhenjilu a = new jiuzhenjilu();
		String 医生工号 = request.getParameter("yishenid");
		/*
		System.out.println(request.getParameter("id"));
		System.out.println(医生工号);
		*/
		String 病人身份证号 = request.getParameter("bingrenid");
		String 疾病 = request.getParameter("jibing");
		String 症状 = request.getParameter("zhengzhuang");
		String 医嘱 = request.getParameter("yizhu");
		String 检查项目 = request.getParameter("jianchaxiangmu");
		a.set医生工号(医生工号);
		a.set症状(症状);
		if(!StringUtils.isBlank(request.getParameter("chuyuan"))) {
			Date 出院时间 =  Date.valueOf(request.getParameter("chuyuan"));
			a.set出院时间(出院时间);
		}
		else
		{
			Date 出院时间 =  Date.valueOf("2000-01-01");
			a.set出院时间(出院时间);
		}
		a.set病人身份证号(病人身份证号);
		a.set疾病(疾病);
		a.set检查项目(检查项目);
		a.set医嘱(医嘱);
		if(!StringUtils.isBlank(request.getParameter("ruyuan"))) {
			Date 入院时间 =  Date.valueOf(request.getParameter("ruyuan"));
			a.set入院时间(入院时间);
		}
		else
		{
			Date 入院时间 =  Date.valueOf("2000-01-01");
			a.set入院时间(入院时间);
		}
		if(!StringUtils.isBlank(request.getParameter("riqi"))) {
			Date 日期 =  Date.valueOf(request.getParameter("riqi"));
			a.set日期(日期);
		}
		else {
			Date 日期 =  Date.valueOf("2000-01-01");
			a.set日期(日期);
		}
		if(!StringUtils.isBlank(request.getParameter("xiaci"))) {
			Date 下次复诊时间 = Date.valueOf(request.getParameter("xiaci"));
			a.set下次复诊时间(下次复诊时间);
		}
		else {
			Date 下次复诊时间 = Date.valueOf("2000-01-01");
			a.set下次复诊时间(下次复诊时间);
		}
		String path = request.getContextPath();
		String basePath =  request.getScheme() + "://" + request.getServerName()  + ":" + request.getServerPort()  + path  + "/";
		try {
			new jiuzhenjiluDao().update(a);
			response.sendRedirect(basePath +"jiuzhenjilu?method=list");
		} catch (IOException e) {
			e. printStackTrace();
		}
	}
	private void look(HttpServletRequest request, HttpServletResponse response) {
		Date 日期 =  Date.valueOf(request.getParameter("riqi"));
		String 病人身份证号 = request.getParameter("bingrenid");
		String 医生工号 = request.getParameter("yishenid");
		try {
			jiuzhenjilu 就诊记录 = new jiuzhenjiluDao().findBy病人身份证号(医生工号, 病人身份证号, 日期);
			request.setAttribute("就诊记录", 就诊记录);
			request.getRequestDispatcher("page/jiuzhenjilu/look.jsp").forward(request, response);

		} catch (Exception e) {
			e. printStackTrace();
		}
	}
}
